import os
from benchbot import BenchBot
from yolo import Detector

detector = Detector()

with BenchBot() as benchbot:
  locations = benchbot.get('locations')
  locations.sort()

  for location in locations:
    benchbot.send('goto', {'location_id': location})
    
    image = benchbot.getImage()

    detections = detector.detect(image)

    found = filter(lambda detection: detection[0] == 'bottle', detections)

    if found:
      break

  benchbot.complete('main', {'data': location if found else ''})
  print 'Found at:', location if found else ''
